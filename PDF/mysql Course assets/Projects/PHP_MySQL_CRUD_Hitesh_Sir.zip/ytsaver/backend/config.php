<?php

class Credentials
{

	const host = "localhost";
	const user = "root";
	const pwd = "";
	const database = "youtube_db";

}


?>

# Travel-Insurance-Data-Analysis
## OBJECTIVE:
Objective is to Analyze Travel Insurance Data to find Meaningful Insights.
## PROBLEM STATEMENT:
Finance is used as a collective term to refer to a broad range of economic services provided by 
the finance industry, which encompasses a broad range of organizations that manage money, 
including credit unions, banks, credit card companies, insurance companies, consumer finance 
companies, stock brokerages, investment funds.
Do ETL : Extract-Transform-Load the dataset and find for me 
some information from this large data. This is form of data mining.
What all information can be achieved by mining this data, would be
brainstormed by the interns
Find key metrics and factors and show the meaningful relationships between attributes.
## DATASET: 
https://drive.google.com/file/d/1Rtk2ghGotR4NVOSKCSPi3LyTMm99n3Zc/view?usp=sharing
## TECHNOLOGY:
Business Intelligence
## DOMAIN:
Banking, Insurance and Finance
## TOOLS:
MS POWER BI, MS EXCEL
## LINKEDIN: 
https://www.linkedin.com/posts/rahul-gupta-0b10bb21b_travel-insurance-analysis-dataanalysis-activity-6928692178655342592-RhoK?utm_source=linkedin_share&utm_medium=member_desktop_web
## VIDEO LINK:
https://youtu.be/uj2go8LOAnw
